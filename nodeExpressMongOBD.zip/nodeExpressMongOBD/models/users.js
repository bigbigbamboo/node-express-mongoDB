const model = db.model('users',{
	uname:{type:String, default:"匿名者"},
	pwd:{type: String},
	sex:{type:String, default: '女'},
	age:{type:Number, default: 18}
})

// 封装方法


// 导出
module.exports = {
    
}