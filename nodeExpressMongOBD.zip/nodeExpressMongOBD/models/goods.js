const model = db.model('goods',{
	title:{type:String, default:"匿名者"},
	price:{type: Number},
})

// 封装方法
const getGoodsDB = ({},pageno,pagesize,token) => {
	let pagestart = (pageno - 1) * pagesize
	return model.find().skip(pagestart).limit(pagesize)
	.then(res => {
		return res
	})
	.catch(err => {
		console.log(err)
		return []
	})
	 
}

// 导出
module.exports = {
    getGoodsDB
}