const model = db.model('users',{
	uname:{type:String, default:"匿名者"},
	pwd:{type: String},
	sex:{type:String, default: '男'},
	age:{type:Number, default: 18}
})

// 封装方法
const postPublicReg = ({uname,pwd}) =>{
	const insertObj = new model({uname,pwd})
	return insertObj.save()
	.then(res=>{
		return res
	})
	.catch(err => {
		console.log('插入失败' + err)
		return []
	})
}

const postPublicFindOne = ({uname}) =>{
	return model.findOne({uname}) 
	.then(res => {
		return res
	})
	.catch(err => {
		console.log(err)
		return false
	})
}

// 导出
module.exports = {
	postPublicReg,
	postPublicFindOne
}