const express = require('express');
const router = express.Router();


const { list } = require(process.cwd() + '/controller/goods')
 

console.log(list)
/* GET home page. */
router.get('/list',list);

module.exports = router;
