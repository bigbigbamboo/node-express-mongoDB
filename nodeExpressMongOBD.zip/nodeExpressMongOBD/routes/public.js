const express = require('express');
const router = express.Router();


const {reg,login,captcha,list} = require(process.cwd() + '/controller/public')


const session = require('express-session')
router.use(session({
  secret: 'a1dk3ddsf2d',	// 加密存储（加盐）
  // resave是指每次请求都重新设置session cookie，
  // 假设你的cookie是10分钟过期，每次请求都会再设置10分钟
  resave: false,		  	
  saveUninitialized: true,   // 初始化session存储
  cookie: {maxAge: 60000}	// 过期时间/毫秒  1分钟=60秒=1000*60  
}))


router.post('/reg', reg);  //注册
router.post('/login', login);  //登录
router.get('/captcha', captcha);  //验证码

 


module.exports = router;
