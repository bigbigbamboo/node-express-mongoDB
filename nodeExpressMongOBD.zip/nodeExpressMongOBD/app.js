var createError = require('http-errors');
var express = require('express');
var path = require('path');
var cookieParser = require('cookie-parser');
var logger = require('morgan');

require(process.cwd() + "/common/db.js")
require(process.cwd() + "/common/utils.js") 

var app = express();


//静态资源加载
app.use(express.static(path.join(__dirname, 'public')));

const jwt = require("jsonwebtoken")
// 切记放到所有路由前面
// app.use('/', (req,res,next) => { // 请求地址是/ 可以省略不写
  app.use((req,res,next) => { // next是express app对象方法的形参
    // 登录注册接口直接跳过
    if (req.url == "/public/login" 
      || req.url == "/public/reg" 
      || req.url == "/public/captcha"
      || req.url == "/goods/list"
      || req.url == "/upload") {
        //在express中只要第一个路由匹配了，就不会走下一个路由
        //通过next语法可以继续向下匹配其他路由
        next()
    } else {
     	if (!req.body) req.body = {}
        let token = req.query.token || req.body.token || req.headers["authorization"];
        jwt.verify(token, '1', (err, decode) => {//decode是之前存的对象信息
            if (err) return sendJson(res, 400, 'TOKEN参数有误100')
            req._id = decode.data._id  //将数据存到req对象中（后面路由的req都想都会有这个uid属性）
            console.log(`解密成功，用户编号【${decode.data._id}】并已保存到req对象中`)
            console.log(decode) // 对象，里面是之前存的信息
            next() 
        })
    }
  });

var indexRouter = require('./routes/index');
var usersRouter = require('./routes/users');
var publicRouter = require('./routes/public');
var goodsRouter = require('./routes/goods');



// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'jade');

app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());


app.use('/', indexRouter);
app.use('/users', usersRouter);
app.use('/public', publicRouter);
app.use('/goods', goodsRouter);




const fs = require('fs')
const multer  = require('multer')
const upload = multer({ dest: './public/uploads'  })
const qiniu = require('qiniu')


app.post('/upload', upload.single('avatar'), function (req, res, next) {
 
  var oldFile = req.file.path
  var newFile = req.file.filename + path.extname(req.file.originalname)

  fs.rename(oldFile, newFile, err => {
    if (err) throw err;
    //  res.send('ok')
    const accessKey = 'lfJfOXL0JPFxs1ShWNwOBaBxk7YQS_BOyXeFVZR8' // 【改】
    const secretKey = 'MwgNj9JjJNk5rzn5MTEE8LwrRC8ed3fb40XLFTBO' // 【改】
    const mac = new qiniu.auth.digest.Mac(accessKey, secretKey)
    var options = { // 自定义凭证有效期（示例2小时，expires单位为秒，为上传凭证的有效时间）
      scope: 'web1908',  // 对象存储空间名称【重要 得改成自己的】
      expires: 7200
    }
    var putPolicy = new qiniu.rs.PutPolicy(options)
    var uploadToken = putPolicy.uploadToken(mac)
    
    // 步骤3：上传
    var localFile = newFile
    var qiniuFileName = newFile
    var putExtra = new qiniu.form_up.PutExtra()
    var formUploader = new qiniu.form_up.FormUploader()
    
    formUploader.putFile(uploadToken, qiniuFileName, localFile, putExtra, function(respErr,
      respBody, respInfo) {
      if (respErr) {
        throw respErr;
      }
      if (respInfo.statusCode == 200) {
        console.log(respBody);
      return res.json({
           meta:{
             state:200,
             msg:"上传成功"
           },
           img:newFile
         })
      } else {
        console.log(respInfo.statusCode);
        console.log(respBody);
      }
    });
    
    
        //-----------------------------
      });
    
      
    })
 



// catch 404 and forward to error handler
app.use(function(req, res, next) {
  next(createError(404));
});

// error handler
app.use(function(err, req, res, next) {
  // set locals, only providing error in development
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};

  // render the error page
  res.status(err.status || 500);
  res.render('error');
});





module.exports = app;
