
 const {getGoodsDB} = require(process.cwd() + '/models/goods')
 
const list = async(req,res) => {
    // let {pageno,pagesize} = req.query
    // console.log(req._id,100)
    console.log(req.query)
    token = req.query.token
    
    let pageno = parseInt(req.query.pageno) || 1
    let pagesize = parseInt(req.query.pagesize) || 2
    if(!req.query.token)return sendJson(res, 400, 'token不能为空y')
    // if(req.query.token != 1)return sendJson(res, 400, 'token参数有误111')
   let data =await getGoodsDB({},pageno,pagesize,token)
   return sendJson(res, 200, '操作成功',data)
}



module.exports = {
    list
}