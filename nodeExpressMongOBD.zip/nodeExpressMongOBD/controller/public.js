const bcrypt = require('bcrypt'); //加密
const svgCaptcha = require('svg-captcha');//验证码
const session = require('express-session')
const jwt = require('jsonwebtoken'); //token

const {postPublicReg,postPublicFindOne} = require(process.cwd() + '/models/public')


//注册
const reg = async(req, res) => {
    // res.send('hello this is public reg')
    let {uname,pwd} = req.body
    //判读账号密码不能为空
    if(!uname || !pwd)return sendJson(res, 400, '账号或密码不能为空')
    //查看数据是否已经存在
    let data = await postPublicFindOne({uname})
    console.log(data)
    if(data)return sendJson(res, 400, '账号已存在1')
    //匹配成功可以注册
    pwd = bcrypt.hashSync(pwd, 7);
    let rs = await postPublicReg({uname,pwd})
    if(rs){
        return sendJson(res, 201, '注册成功',data)
    }else{
        return sendJson(res, 500, '服务器爆炸啦')
    }
    
}


//登录
const login = async(req, res) => {
    // res.send('hello this is public reg')
    // let {uname,pwd,captcha} = req.body
    let {uname,pwd,captcha} = req.body
   
    //判读账号密码不能为空
    if(!uname || !pwd)return sendJson(res, 400, '账号或密码不能为空1')
    if(!captcha)return sendJson(res, 400, '验证码不能为空')
    console.log(req.session.captcha ,111)
    if(captcha.toUpperCase() != req.session.captcha.toUpperCase() )return sendJson(res, 400, "验证码有误")
    //查看数据是否已经存在
    let data = await postPublicFindOne({uname})
    if(!data)return sendJson(res, 400, '账号不存在')
    //匹配密码
    if (!bcrypt.compareSync(pwd, data.pwd)) return sendJson(res, 401, '密码错误')
    // if(pwd != data.pwd)return sendJson(res, 401, '密码错误') 
    return sendJson(res, 200, '登录成功',{
        uname:data.uname,
        token:jwt.sign({ data: data }, '1')
    })
     
}


//获取验证码
const captcha = (req,res) => {
    const captcha = svgCaptcha.create();
    // console.log(captcha)
    req.session.captcha = captcha.text 
    console.log(req.session.captcha ,222)
    res.send(captcha.data)
}






module.exports = {
    reg,
    login,
    captcha
}